Kenia Castro
COP 3402 - Summer 2017
HW #1 pMachine
ReadMe File

============================================================================
			                | File Contents |

1. pMachine.c
2. vminput.txt
3. vmoutput.txt

=============================================================================
			                | Instructions |

1. Please make sure the input file is called 'vminput.txt'.

2. Compile the file "pMachine.c" at the command line by typing:
	gcc pMachine.c

3. Then, run the program by typing:
	./a.out
   
4. The printout in interpreted assmebly language will be printed to the output 
   text file called 'vmoutput.txt'. The printout of the execution of the 
   program in the virtual machine showing the PC, BP, SP, and stack will also 
   print to the same output text file.

4. Some text editors don't properly display the formatting of the output file 
   and create weird spacing. My specific output file was tested on Visual 
   Studio Code and WordPad.

===============================================================================

